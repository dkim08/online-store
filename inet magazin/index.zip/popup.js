
function showPopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'block';
}

function hidePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}

//////////////////////////

function showPopup2() {
    var popup = document.getElementById('popup_2');
    popup.style.display = 'block';
}

function hidePopup2() {
    var popup = document.getElementById('popup_2');
    popup.style.display = 'none';
}

////////////////////////////

function showPopup3() {
    var popup = document.getElementById('popup_3');
    popup.style.display = 'block';
}

function hidePopup3() {
    var popup = document.getElementById('popup_3');
    popup.style.display = 'none';
}

///////////////////////////////

function showPopup4() {
    var popup = document.getElementById('popup_4');
    popup.style.display = 'block';
}

function hidePopup4() {
    var popup = document.getElementById('popup_4');
    popup.style.display = 'none';
}

///////////////////////////////

function showPopup5() {
    var popup = document.getElementById('popup_5');
    popup.style.display = 'block';
}

function hidePopup5() {
    var popup = document.getElementById('popup_5');
    popup.style.display = 'none';
}

///////////////////////////////

function showPopup6() {
    var popup = document.getElementById('popup_6');
    popup.style.display = 'block';
}

function hidePopup6() {
    var popup = document.getElementById('popup_6');
    popup.style.display = 'none';
}

///////////////////////////////

function showPopup7() {
    var popup = document.getElementById('popup_7');
    popup.style.display = 'block';
}

function hidePopup7() {
    var popup = document.getElementById('popup_7');
    popup.style.display = 'none';
}

///////////////////////////////

function showPopup8() {
    var popup = document.getElementById('popup_8');
    popup.style.display = 'block';
}

function hidePopup8() {
    var popup = document.getElementById('popup_8');
    popup.style.display = 'none';
}

/////////////////////////////